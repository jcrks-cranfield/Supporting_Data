igneous_forms_v1:

Contains geochemical data for 9 igneous formations, from 8 references. Values from the original literature were converted from oxides to whole elements, then from wt% (weight percent) to ppm (parts per million). These values are compiled for each formation. Column headers are normal-case element symbols, excluding LOI(%) and Total(%), which represent loss on ignition and the sum of each element's wt%, respectively. Within each formation, there are entries for subsamples, the mean, and STDEV (standard deviation).

igneous_forms_v2:

Contains mean elemental concentrations for 8 formations, with Cheviot Hills excluded due to lacking Chromium. Elements listed are base cations and Titanium, Nickel, and Chromium. These were selected as the only immobile elements consistently present in each original dataset. Elemental concentration headers (e.g. CA_PPM) are accompanied by their standard deviation between subsamples of that formation (e.g. CA_STD). EASTING and NORTHING provide approximate XY coordinates (British National Grid) for the location of a formation. Coordinates were not provided for all samples in every formation, so these locations are estimates of the formation's centre, or where samples are taken across a region, the centre of samples obtained.



