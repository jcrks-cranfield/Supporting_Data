README for MATLAB scripts and functions used in Crooks et al. (2026). Separate READMEs exist for datasets within  'pairings_analysis_v1' -> 'data'

MATLAB scripts can be found in 'pairings_analysis_v1' -> 'scripts'. analyse_resolvability_GEOROC.m and analyse_resolvability_formations.m calculate the phi resolvability parameter, optimal immobile tracers, and required application rates to resolve weathering across England and Wales. analyse_resolvability_GEOROC applies these calculations to the compositions of 137 UK basalt samples from the GEOROC repository, while analyse_resolvability_formations.m applies them to 8 UK igneous formations. These scripts also produce figures used in the paper. These scripts require the functions app2massfract.m, appdissreq.m, and phiresolvability.m, found in 'pairings_analysis_v1' -> 'functions'. They must be run in the 'scripts' directory within 'parings_analysis_v1'.

The script 'gridding_bulk_dens' attaches bulk density values from the LandIS HORIZON Hydraulics dataset to NSI sample locations, exports these values for ArcGIS interpolation, then projects these interpolated values onto the same grid as the elemental data. It will not run without the LandIS HORIZON Hydraulics and NSI Site datasets, which are not publicly available. This code is therefore provided as a methodological reference.

All code was generated using MATLAB R2025b.

-----------------------------------------------------------------------------------------------------------
variable naming conventions:

variables are named to first describe the parameter, then its origin or further descriptors. 

variables relating to the GEOROC samples have the suffix 'geo', e.g. basalt_geo, while variables relating to the igneous formations have the prefix 'form', e.g. 'basalt_form'. 

variables with the suffix 'grid' share the same size as the original 640x515 elemental concentration grids.

variables including mass fraction will denote this as 'mf', e.g., mf_grid

variables including bulk density will denote this as 'bd', e.g. bd_val

variables which represent changing immobile elements within a loop have the prefix 'dynamic'

cubic matrices end with the suffix '3D' e.g. 'ca_f_geo3D'

single column variables end with the suffix 'flat'

'f' refers to feedstock

'ix' refers to index or indices

'res' refers to resolvability

'pct' refers to percentage

'valid' refers to variables which have had impossible or non-number values filtered out, or have had their units corrected

Elements are labelled in lowercase when part of variable names, e.g. ca, mg, na, ti, ni, cr. A combination of ca & mg is denoted as 'camg', while a combination of all base cations together is denoted as 'CAT'.


