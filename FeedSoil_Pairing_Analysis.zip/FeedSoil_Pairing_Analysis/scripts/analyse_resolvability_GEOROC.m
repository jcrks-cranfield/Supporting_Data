% Script for plotting phi resolvability and requisite application for a range of basalts and tracers
% across England and Wales, using a variable bulk density. Basalts used are
% from GEOROC dataset.

%-----------------------------------------------------------------------------

% !NOTE! requires LandIS bulk density data which are not publicly available as
% of Jan 2026. Code from line 84 onwards will not run without this data.

%---------------------------------------------------------------------

% Clear workspace
clc
clear
close all

%% Import UK Soil Element Data

elems_BGS = {'Ag','Al','As','Ba','Bi','Br','Ca','Cd','Ce','Cl','Co','Cr','Cs','Cu','Fe',...
             'Ga','Ge','Hf','I','In','K','La','Mg','Mn','Mo','Na','Nb','Nd','Ni','P',...
             'Pb','Pd','Rb','S','Sb','Sc','Se','Si','Sm','Sn','Sr','Ta','Th','Ti','Tl',...
             'U','V','W','Y','Yb','Zn','Zr'};

% elements with units wt% within BGS data (all else ppm)
wtPerc_elems = {'Al','Ca','Fe','K','Mg','Mn','Na','P','Si','Ti'}; 
%NaN rows to be removed from data grid
n_extra_rows = 6;   
%conversion from wt% to ppm
perc_2_ppm = 10000;  
%marker for non-values
no_val = -1;           
%preacllocate structure to host element grids
soil_struc = struct(); 

%loop through folder to place element grids in structure
for f = 1:numel(elems_BGS)

        filename_BGS = [elems_BGS{f}, '_grid.txt'];
        raw_soil_BGS = readmatrix(fullfile('..', 'data','BGS_topsoil_elem_1km/',filename_BGS)...
            ,'Delimiter',' ', 'NumHeaderLines', n_extra_rows);
        raw_soil_BGS(raw_soil_BGS == no_val) = NaN;
        valid_soil_BGS = raw_soil_BGS;

            %convert wt% elements to ppm
            if ismember(elems_BGS{f}, wtPerc_elems) 
                valid_soil_BGS = valid_soil_BGS * perc_2_ppm;
            end 

    soil_struc.(elems_BGS{f}) = valid_soil_BGS;     
end


%% Import GEOROC basalt samples, filter for those with full tracer data

%import file
rawdata_geo = readtable(fullfile('..','data/','GEOROC_data/','GEOROC_samples_processed.csv'));

%select whole rock samples
whole_ix = string(rawdata_geo.MATERIAL) == 'WHOLE ROCK';                       
rawdata_geo = rawdata_geo(whole_ix,:);     

%select rocks with basalt in name
basalt_ix = contains(string(rawdata_geo.ROCK_NAME),"BASALT","IgnoreCase",true); 
basalt_geo = rawdata_geo(basalt_ix,:);      

%select tracers for analysis
i_list = {'Cr','Ni','Ti','Al','Th','Y','Nb','Hf','Sc'};      
header_list = string(upper(i_list)) + "_PPM";

%extract basalts where data entries exist for tracers in i_list^
tracer_entries = table('Size', [height(basalt_geo), numel(i_list)], 'VariableNames', ...  
  header_list,'VariableTypes', repmat({'double'}, 1, numel(i_list))); 

 for f = 1:length(header_list)
     current_header = header_list(f);
     i_col = basalt_geo.(current_header);
     tracer_entries.(current_header) = i_col; 
 end

nonNaN_ix = ~isnan(tracer_entries{:,:});
valid_rows = all(nonNaN_ix, 2);
basalt_geo = basalt_geo(valid_rows,:);
basalt_geo = basalt_geo(:,10:end);


%% Import soil bulk density and map

%import file
bd_grid = readmatrix(fullfile('..','data/','processing_bulk_density/LandIS_bd_grid.csv'));
grid_NaNmask = isnan(soil_struc.Ag);
bd_grid(flipud(grid_NaNmask)) = NaN;


%% Set inputs for 'base case'

app_rate = 50;      %feedstock application rate in t/ha
plow_depth = 0.1;   %depth of mixing
e_is = 0.1;         %assumed uncertainty on soil tracer concentration
e_js = 0.1;         %assumed uncertainty on soil cation concentration
e_jf = 0.05;        %assumed uncertainty on feedstock cation concentration
e_if = 0.05;        %assumed uncertainty on feedstock tracer concentration
diss = 0.3;         %assumed fraction of rock dissolution
basalt_dens = 2.9;  %basalt density(t/m^3)

%% 6. Create grid of mass fraction values, based on inputs^

%preallocate grids for mass fraction and soil volume
mf_grid = NaN(size(bd_grid));     
vSoil_grid = NaN(size(bd_grid)); 

addpath('..\functions\')

%loop over Eng & Wales grid 

for f = 1:size(bd_grid,1)
    for i = 1:size(bd_grid,2)

        bd_val = bd_grid(f,i);

        if isnan(bd_val)
            continue
        end

        [a_mf, vSoil] = app2massfract(app_rate, bd_val, plow_depth);
        mf_grid(f,i)     = a_mf;
        vSoil_grid(f,i) = vSoil;

    end
end



%% 6. Calculate Phi for all GEOROC basalts at every grid cell, using dynamic tracer selection 

%PREALLOCATE VARIABLES
num_i = numel(i_list);                           %number of tracers
num_f_geo = height(basalt_geo);                  %number of GEOROC feedstocks
[cube_ny, cube_nx] = size(mf_grid);              %cube size   
soil_cube = NaN(cube_ny, cube_nx, num_i);        %preallocate cube of xy spatial grid vs z tracers
ratio_cube = NaN(cube_ny, cube_nx, num_i);       %preallocate cube to store [i]f/[i]s ratios
best_i_cube = NaN(cube_ny, cube_nx, num_f_geo);  %preallocate cube to store optimal tracer indices
phi_geo  = NaN(cube_ny, cube_nx, num_f_geo);     %phi using optimal tracer
phi_geo2 = NaN(cube_ny, cube_nx, num_f_geo);     %phi using 2nd best tracer
phi_geo3 = NaN(cube_ny, cube_nx, num_f_geo);     %phi using 3rd best tracer
unres_mask = flipud(isnan(soil_struc.Ag));       %Mask for non values (sea)


for f = 1:num_f_geo

    for i = 1:num_i
        soil_cube(:,:,i) = flipud(soil_struc.(i_list{i}));
        i_f = basalt_geo.([(upper(i_list{i})) '_PPM'])(f);

        %calculate [i]f/[i]s ratios for this basalt and tracer
        ratio_cube(:,:,i) = i_f ./ soil_cube(:,:,i);

    end

    nan_mask = any(isnan(ratio_cube), 3);

    %rank values along the tracer axis by ratio size
    [sorted_vals, sorted_idx] = sort(ratio_cube, 3, 'descend');

    %identify tracers that perform best, 2nd best, and 3rd best
    best_i       = sorted_idx(:,:,1);  
    second_i     = sorted_idx(:,:,2);   
    third_i     = sorted_idx(:,:,3); 

    best_i(nan_mask)   = NaN;
    second_i(nan_mask) = NaN;
    third_i(nan_mask) = NaN;
    best_i_cube(:,:,f) = best_i;

    %preallocate dynamic tracer selection
    dynamic_i_s  = NaN(size(best_i));
    dynamic_i_f  = NaN(size(best_i));

    dynamic2_i_s = NaN(size(best_i));
    dynamic2_i_f = NaN(size(best_i));

    dynamic3_i_s = NaN(size(best_i));
    dynamic3_i_f = NaN(size(best_i));

    %for the best - 3rd best tracers, extract the [i] concentrations in
    %soil and feedstock

    for k = 1:num_i

        mask1 = (best_i == k);
        klayer = soil_cube(:,:,k);

        if any(mask1(:))
            dynamic_i_s(mask1) = klayer(mask1);
            dynamic_i_f(mask1) = basalt_geo.([(upper(i_list{k})) '_PPM'])(f);
        end

        mask2 = (second_i == k);
        klayer = soil_cube(:,:,k);

        if any(mask2(:))
            dynamic2_i_s(mask2) = klayer(mask2);
            dynamic2_i_f(mask2) = basalt_geo.([(upper(i_list{k})) '_PPM'])(f);
        end
        
        mask3 = (third_i == k);
        klayer = soil_cube(:,:,k);

        if any(mask3(:))
            dynamic3_i_s(mask3) = klayer(mask3);
            dynamic3_i_f(mask3) = basalt_geo.([(upper(i_list{k})) '_PPM'])(f);
        end
    end

    %calculate phi using best, 2nd best and 3rd best tracers
    phi_geo(:,:,f)  = phiresolvability(mf_grid, dynamic_i_s,  dynamic_i_f,  e_is, e_if);
    phi_geo2(:,:,f) = phiresolvability(mf_grid, dynamic2_i_s, dynamic2_i_f, e_is, e_if);
    phi_geo3(:,:,f) = phiresolvability(mf_grid, dynamic3_i_s, dynamic3_i_f, e_is, e_if);
    
end

%flatten values for histogram plotting
phi_geo_flat = phi_geo(:);
phi_geo2_flat = phi_geo2(:);
phi_geo3_flat = phi_geo3(:);

%calculate % of locations where phi transitions to unresolvable for less than optimal tracers
trans_ix2 = phi_geo_flat>1 & phi_geo2_flat<1;
trans_ix3 = phi_geo_flat>1 & phi_geo3_flat<1;
trans_perc2 = mean(trans_ix2).*100;   %percent of values transitioning to phi <1 (using 2nd best)
trans_perc_3 = mean(trans_ix3).*100;   %percent of values transitioning to phi <1 (using 3rd best)



%% Repeat phi calculation for fixed tracer selection
phi_ni_geo = NaN(cube_ny,cube_nx,num_f_geo);
phi_ti_geo = NaN(cube_ny,cube_nx,num_f_geo);
phi_cr_geo = NaN(cube_ny,cube_nx,num_f_geo);

for f = 1:height(basalt_geo)

    phi_ni_geo(:,:,f) = phiresolvability(mf_grid,flipud(soil_struc.Ni),basalt_geo.NI_PPM(f),e_is,e_if);
    phi_ti_geo(:,:,f) = phiresolvability(mf_grid,flipud(soil_struc.Ti),basalt_geo.TI_PPM(f),e_is,e_if);
    phi_cr_geo(:,:,f) = phiresolvability(mf_grid,flipud(soil_struc.Cr),basalt_geo.CR_PPM(f),e_is,e_if);

end


%% Plot mode optimal tracer in GEOROC basalts for each location

%calculate most common optimal tracer at each location
mode_tracer_map = mode(best_i_cube, 3);
opt_tracer_flat = best_i_cube(:);
num_per_tracer = arrayfun(@(k) sum(opt_tracer_flat == k), 1:num_i);

%make discrete colormap
clrmap =     [0.9 0 0          % red
             0.10 0.40 0.90   % blue
             0.50 0.80 0.10   % green
             1 1 0 ];         % yellow

i_used = [1,2,3,9];        %Cr, Ni, Ti, Sc


figure('Position',[10 10 900 350])
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
nexttile
bar(num_per_tracer,'grouped','Facecolor',[0.7 0.7 0.7])
set(gca,'XTick',1:num_i,'XTickLabel',i_list)
set(gca,'Yscale','log')
xlabel('Optimal tracer')
ylabel('Count')
set(gca,'Xgrid','off')
grid on
ylim([10e4 10e7])
title('(a)','FontSize',16);

nexttile
pcolor(mode_tracer_map)
shading flat
colormap(clrmap)
cb = colorbar;
cb.Ticks = 1.35:0.75:3.6;
cb.TickLabels = i_list(i_used);
cb.TickLength = 0;
cb.FontSize = 16;

clim([1 4])
set(gca,'XTick',[],'YTick',[])
axis equal tight
title('(b)','FontSize',16);


%% Calculate percentages of Nickel, Titanium and Scandium as optimal tracers

ni_opt_pct = (num_per_tracer(2)/sum(num_per_tracer))*100;
ti_opt_pct = (num_per_tracer(3)/sum(num_per_tracer))*100;
sc_opt_pct = (num_per_tracer(9)/sum(num_per_tracer))*100;

%% Calculate required application rates for every cation and feedstock

%create 2D grids for cations
ca_grid = flipud(soil_struc.Ca);      
mg_grid = flipud(soil_struc.Mg);
na_grid = flipud(soil_struc.Na);

%get columns of feedstock cation concentration
ca_geo_col = basalt_geo.CA_PPM;   
mg_geo_col = basalt_geo.MG_PPM;
na_geo_col = basalt_geo.NA_PPM;

%create cubes of soil cation grid x number of feedstocks
ca_s_geo3D = repmat(ca_grid, 1, 1, num_f_geo);    
mg_s_geo3D = repmat(mg_grid, 1, 1, num_f_geo);
na_s_geo3D = repmat(na_grid, 1, 1, num_f_geo);

%create cubes of feedstock cation concentrations x number of feedstocks
ca_f_geo3D = reshape(ca_geo_col, 1, 1, num_f_geo);  
mg_f_geo3D = reshape(mg_geo_col, 1, 1, num_f_geo);  
na_f_geo3D = reshape(na_geo_col, 1, 1, num_f_geo);  

%create cubes for mass fraction, soil volume and density
mf_geo3D = repmat(mf_grid,1,1,num_f_geo);
vsoil_geo3D = repmat(vSoil_grid,1,1,num_f_geo);
bd_geo3D = repmat(bd_grid,1,1,num_f_geo);

%calculate required a for ca, mg, and na, for every feedstock
[ca_rate_geo, ~ , ~] = appdissreq(mf_geo3D, ca_s_geo3D, ca_f_geo3D, e_js, e_jf, diss, bd_geo3D, basalt_dens, vsoil_geo3D);
[mg_rate_geo, ~ , ~] = appdissreq(mf_geo3D, mg_s_geo3D, mg_f_geo3D, e_js, e_jf, diss, bd_geo3D, basalt_dens, vsoil_geo3D);
[na_rate_geo, ~ , ~] = appdissreq(mf_geo3D, na_s_geo3D, na_f_geo3D, e_js, e_jf, diss, bd_geo3D, basalt_dens, vsoil_geo3D);

%filter out negative or extreme values
ca_rate_geo(ca_rate_geo < 0 | ca_rate_geo > 5000)= NaN; 
mg_rate_geo(mg_rate_geo < 0 | mg_rate_geo > 5000) = NaN;
na_rate_geo(na_rate_geo < 0 | na_rate_geo > 5000) = NaN;

%%
%required application rate to resolve ALL cations
CAT_stack = cat(4, ca_rate_geo, mg_rate_geo, na_rate_geo);
camg_stack = cat(4, ca_rate_geo, mg_rate_geo);

% Take the maximum across the 4th dimension
CAT_rate_geo = max(CAT_stack, [], 4);
camg_rate_geo = max(camg_stack, [], 4);

%% Plot histograms of phi at basalt performance percentiles

% Pick out percentiles
f_prctiles = 10:20:90;
f_prc_ix = round(prctile(1:num_f_geo, f_prctiles));

%rank basalts by phi
phi_rank_geo = sort(phi_geo, 3,'ascend');

xlims = [0 4];
ylims = [0 25000];
clim_max = 4;

figure
for p = 1:length(f_prc_ix)

    f = f_prc_ix(p);
    phi_slice = phi_rank_geo(:,:,f);
    phi_flat = phi_slice(:);
    phi_flat = phi_flat(~isnan(phi_flat));

    % calculate resolvable land area
    pct_res = 100 * sum(phi_flat >= 1) / numel(phi_flat);

    subplot(1,5,p)
    histogram(phi_flat, 'BinLimits', [0 clim_max], 'BinWidth', 0.1)
    ylim(ylims)
    xlim(xlims)
    xlabel('\phi'); ylabel('Count')
    xline(1, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1)
    title(sprintf('%dth percentile', f_prctiles(p)))
    text(0.45, 0.9, ...
         sprintf('Res. = %.1f%%', pct_res), ...
         'Units', 'normalized', ...
         'VerticalAlignment', 'top', ...
         'FontSize', 10, ...
         'BackgroundColor', 'w', ...
         'Margin', 4)
end

%% Plot histograms of required application for Ca, Mg and Na

%rank A by value
ca_rank_geo = sort(ca_rate_geo,3,'descend');
mg_rank_geo = sort(mg_rate_geo,3,'descend');
na_rank_geo = sort(na_rate_geo,3,'descend');
CAT_rank_geo = sort(CAT_rate_geo,3,'descend');
camg_rank_geo = sort(camg_rate_geo,3,'descend');

xlims = [0 150];
ylims = [0 5000];
binwidth = 2.5;

figure
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
 
    %calcium
    subplot(3,5,p)                  
    ca_slice = ca_rank_geo(:,:,f); 
    ca_flat = ca_slice(:);
    ca_flat = ca_flat(~isnan(ca_flat));

    histogram(ca_flat, 'BinWidth', binwidth)  
    xlim(xlims)
    ylim(ylims)
    ylabel('Count')
    title(sprintf('%dth percentile', f_prctiles(p)))
    xline(app_rate, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1)

    if p == 1
        ylabel('Count')
        text(-0.6, 0.2, 'Calcium', 'Units','normalized', ...
             'FontWeight','bold','FontSize',12,'Rotation',90)
    end

    %magnesium
    subplot(3,5,5 + p)           
    mg_slice = mg_rank_geo(:,:,f); 
    mg_flat = mg_slice(:);
    mg_flat = mg_flat(~isnan(mg_flat));

    histogram(mg_flat, 'BinWidth', binwidth)
    ylim(ylims)
    xlim(xlims)
    xline(app_rate, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1)

    if p == 1
        ylabel('Count')
        text(-0.6, 0.15, 'Magnesium', 'Units','normalized', ...
             'FontWeight','bold','FontSize',12,'Rotation',90)
    end

    %sodium
    subplot(3,5,10 + p)       
    na_slice = na_rank_geo(:,:,f);
    na_flat = na_slice(:);
    na_flat = na_flat(~isnan(na_flat));

    histogram(na_flat, 'BinWidth', binwidth)
    xlabel(' Application (t/ha)')
    ylim(ylims)
    xlim(xlims)
    xline(app_rate, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1)

    if p == 1
        ylabel('Count')
        text(-0.6, 0.24, 'Sodium', 'Units','normalized', ...
             'FontWeight','bold','FontSize',12,'Rotation',90)
    end
end


%% Plot smoothed histograms for Phi, a(Ca), a(Mg), and a(Na) at basalt perfentiles

figure
tiledlayout(2,3,"TileSpacing","compact","Padding","compact");  
linecol = lines(5);
binwidth_phi = 0.1;
xlim_a = [0 100];
ylim_a = [0 100];

%Phi
nexttile
hold on
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
    phi_slice = phi_rank_geo(:,:,f);
    phi_flat = phi_slice(:);
    phi_flat = phi_flat(~isnan(phi_flat));
    [counts, edges] = histcounts(phi_flat,'BinWidth', binwidth_phi,'Normalization', 'cdf');
    centers = edges(1:end-1) + diff(edges)/2;
    plot(centers, counts*100, 'LineWidth', 1.2, 'Color', linecol(p,:))

end

xlim([0 3])
ylim([0 100])
ylabel('Land area (%)')
xlabel('\phi')
title('(a)')
grid on
hold off

%Calcium
nexttile
hold on
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
    ca_slice = ca_rank_geo(:,:,f);
    ca_flat = ca_slice(:);
    ca_flat = ca_flat(~isnan(ca_flat));
    [counts, edges] = histcounts(ca_flat,'BinWidth', binwidth_phi,'Normalization', 'cdf');
    centers = edges(1:end-1) + diff(edges)/2;
    plot(centers, counts*100, 'LineWidth', 1.2, 'Color', linecol(p,:))
end

title('(b)')
grid on
xlim(xlim_a)
ylim(ylim_a)
xlabel('Application amount (t ha^-^1)')
hold off

%Magnesium
nexttile
hold on
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
    mg_slice = mg_rank_geo(:,:,f);
    mg_flat = mg_slice(:);
    mg_flat = mg_flat(~isnan(mg_flat));
    [counts, edges] = histcounts(mg_flat,'BinWidth', binwidth_phi,'Normalization', 'cdf');
    centers = edges(1:end-1) + diff(edges)/2;
    plot(centers, counts*100, 'LineWidth', 1.2, 'Color', linecol(p,:))
end

title('(c)')
grid on
xlim(xlim_a)
ylim(ylim_a)
xlabel('Application amount (t ha^-^1)')
hold off

%Sodium
nexttile
hold on
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
    na_slice = na_rank_geo(:,:,f);
    na_flat = na_slice(:);
    na_flat = na_flat(~isnan(na_flat));
    [counts, edges] = histcounts(na_flat,'BinWidth', binwidth_phi,'Normalization', 'cdf');
    centers = edges(1:end-1) + diff(edges)/2;
    plot(centers, counts*100, 'LineWidth', 1.2, 'Color', linecol(p,:))
end

xlabel('Application amount (t ha^-^1)')
title('(d)')
grid on
xlim(xlim_a)
ylim(ylim_a)
hold off

%All Cations
nexttile
hold on
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
    CAT_slice = CAT_rank_geo(:,:,f);
    CAT_flat = CAT_slice(:);
    CAT_flat = CAT_flat(~isnan(CAT_flat));
    [counts, edges] = histcounts(CAT_flat,'BinWidth', binwidth_phi,'Normalization', 'cdf');
    centers = edges(1:end-1) + diff(edges)/2;
    plot(centers, counts*100, 'LineWidth', 1.2, 'Color', linecol(p,:))
end

xlabel('Application amount (t ha^-^1)')
title('(ALL)')
grid on
xlim(xlim_a)
ylim(ylim_a)
hold off

%Ca+Mg
nexttile
hold on
for p = 1:length(f_prc_ix)
    f = f_prc_ix(p);
    camg_slice = camg_rank_geo(:,:,f);
    camg_flat = camg_slice(:);
    camg_flat = camg_flat(~isnan(camg_flat));
    [counts, edges] = histcounts(camg_flat,'BinWidth', binwidth_phi,'Normalization', 'cdf');
    centers = edges(1:end-1) + diff(edges)/2;
    plot(centers, counts*100, 'LineWidth', 1.2, 'Color', linecol(p,:))
end

xlabel('Application amount (t ha^-^1)')
title('(Ca+Mg)')
grid on
xlim(xlim_a)
ylim(ylim_a)
hold off

% Legend
legend_strings = arrayfun(@(x) sprintf('%d%%ile', x), f_prctiles, 'UniformOutput', false);
lg = legend(legend_strings,'Orientation','vertical','Location','northwest');
lg.Title.String = 'Percentile of UK Basalts';



%% Calculate percentages of basalts that resolve in different scenarios

%percent resolvable (phi) using dymanic tracer selection
phi_res_pct = round(100 * mean(phi_geo >= 1, 3)); 
phi_res_pct(all(isnan(phi_geo), 3)) = NaN;

%phi using ti
ti_phi_res_pct = round(100 * mean(phi_ti_geo >= 1, 3)); 
ti_phi_res_pct(all(isnan(phi_ti_geo), 3)) = NaN;

%phi using cr
cr_phi_res_pct = round(100 * mean(phi_cr_geo >= 1, 3)); 
cr_phi_res_pct(all(isnan(phi_cr_geo), 3)) = NaN;

%phi using ni
ni_phi_res_pct = round(100 * mean(phi_ni_geo >= 1, 3)); 
ni_phi_res_pct(all(isnan(phi_ni_geo), 3)) = NaN;

%calcium
ca_res_pct =  round(100 * mean(ca_rate_geo < app_rate, 3)); 
ca_res_pct(unres_mask) = NaN;

%magnesium
mg_res_pct =  round(100 * mean(mg_rate_geo < app_rate, 3)); 
mg_res_pct(unres_mask) = NaN;

%sodium
na_res_pct =  round(100 * mean(na_rate_geo < app_rate, 3)); 
na_res_pct(unres_mask) = NaN;

%calcium & magnesium
camg_res_pct = 100 * mean((ca_rate_geo < app_rate) & (mg_rate_geo < app_rate),3);
camg_res_pct(unres_mask) = NaN;

% %calcium & magnesium & phi
camg_phi_res_pct = 100 * mean((ca_rate_geo < app_rate) & (mg_rate_geo < app_rate),3);
camg_phi_res_pct(unres_mask) = NaN;

%calcium & magnesium & sodium
CAT_res_pct = 100 * mean((ca_rate_geo < app_rate) & (mg_rate_geo < app_rate) & (na_rate_geo < app_rate),3);
CAT_res_pct = round(CAT_res_pct);
CAT_res_pct(unres_mask) = NaN;  

%phi using dynamic tracer & calcium & magnesium & sodium 
CAT_phi_res_pct = 100 * mean((ca_rate_geo < app_rate) & (mg_rate_geo < app_rate) & (na_rate_geo < app_rate) & (phi_geo >= 1),3);
CAT_phi_res_pct(unres_mask) = NaN;

%% Map resolvable basalt percentages for different scenarios

figure
tiledlayout(2,3,'TileSpacing','tight','Padding','tight');
clims = [0 100];

%Phi
nexttile
pcolor(phi_res_pct)
shading flat
hold on
zero_mask = (phi_res_pct == 0);
h = pcolor(zero_mask);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_mask * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(a) Feed. input','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none');


%Calcium
nexttile
pcolor(ca_res_pct)
shading flat
hold on
zero_mask = (ca_res_pct == 0);
h = pcolor(zero_mask);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_mask * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(b) [Ca] loss','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none');

%Magnesium
nexttile                 
pcolor(mg_res_pct)
shading flat
hold on
zero_maskC = (mg_res_pct == 0);
h = pcolor(zero_maskC);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_maskC * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(c) [Mg] loss','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none');

%Sodium
nexttile
pcolor(na_res_pct); 
shading flat
hold on
zero_mask = (na_res_pct == 0);
h = pcolor(zero_mask);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_mask * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(d) [Na] loss','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none');

%all cations
nexttile
pcolor(CAT_res_pct); 
shading flat
hold on
zero_mask = (CAT_res_pct == 0);
h = pcolor(zero_mask);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_mask * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(e) [Ca & Mg & Na] loss','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none');


%Calcium and Magnesium and Phi
nexttile
pcolor(camg_phi_res_pct); 
shading flat
hold on
zero_mask = (camg_phi_res_pct == 0);
h = pcolor(zero_mask);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_mask * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(f) Feed. input & [Ca & Mg] loss','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none')

%colorbar
cb = colorbar;
cb.Layout.Tile = 'east';   % attach to right side of tiled layout
cb.Label.String = '% of basalts';
cb.Label.Rotation = 270;
cb.Label.FontSize = 11;
cb.FontSize = 10;

addpath('..\data\colormaps\')
clrmp = load("Colormaps\lipari.mat");
colormap(clrmp.lipari)

%%
figure
pcolor(camg_phi_res_pct); 
shading flat
hold on
zero_mask = (camg_phi_res_pct == 0);
h = pcolor(zero_mask);
set(h, 'FaceColor', [0.7 0.7 0.7], 'EdgeColor', 'none')
alpha(h, zero_mask * 1)
xticks([])
yticks([])
axis equal tight
clim(clims)
title('(f) Feed. input & [Ca & Mg] loss','FontSize',15);
set(gca, 'XColor', 'none', 'YColor', 'none')

%% Plot histograms for the above maps

figure
tiledlayout(2,3,'TileSpacing','tight','Padding','tight');
bins = 0:5:100;

phi_pct_valid = phi_res_pct(~isnan(phi_res_pct) & phi_res_pct > 0);
ca_pct_valid  = ca_res_pct(~isnan(ca_res_pct) & ca_res_pct > 0);
mg_pct_valid  = mg_res_pct(~isnan(mg_res_pct) & mg_res_pct > 0);
na_pct_valid  = na_res_pct(~isnan(na_res_pct) & na_res_pct > 0);
camg_pct_valid = camg_res_pct(~isnan(camg_res_pct) & camg_res_pct > 0);
CAT_pct_valid = CAT_res_pct(~isnan(CAT_res_pct) & CAT_res_pct > 0);

hist_titles = {'(a) Feedstock addition'
               '(b) [Ca] loss'
               '(c) [Mg] loss'
               '(d) [Na] loss'
               '(e) [Ca & Mg] loss'
               '(f) [Ca & Mg & Na]'};

hist_data = {phi_pct_valid, ca_pct_valid, mg_pct_valid, na_pct_valid, camg_pct_valid, CAT_pct_valid};

for i = 1:6

    nexttile
    pcts = hist_data{i};
    histogram(pcts, bins, 'Normalization', 'percentage',...
              'EdgeColor','k','FaceColor',[0.5 0.5 0.5],'FaceAlpha',1);
    xlim([0 100])
    ylim([0 80])
    title(hist_titles{i})
    set(gca,'FontSize',10)
    grid on

    if i == 1 || i == 4
        ylabel('Land area (%)')
    end

    if i>3
        xlabel('% of basalts resolvable')
    end
  
end

%% Map and plot histogram for % of basalts reolving using optimised vs fixed tracers

ti_phi_pct_valid = ti_phi_res_pct(~isnan(ti_phi_res_pct) & ti_phi_res_pct > 0);
cr_phi_pct_valid = cr_phi_res_pct(~isnan(cr_phi_res_pct) & cr_phi_res_pct > 0);
ni_phi_pct_valid = ni_phi_res_pct(~isnan(ni_phi_res_pct) & ni_phi_res_pct > 0);

hist_titles = {'(a) i = Optimal'
               '(b) i = Ni'
               '(c) i = Cr'
               '(d) i = Ti'};

map_data = {phi_res_pct, ni_phi_res_pct,cr_phi_res_pct,ti_phi_res_pct};
hist_data = {phi_pct_valid, ni_phi_pct_valid, cr_phi_pct_valid, ti_phi_pct_valid};

clrmp = load("Colormaps\lipari.mat"); 
lipari = clrmp.lipari;                  
grey = [0.7 0.7 0.7];                   
grey_map = [grey; lipari];              

figure
t = tiledlayout(2,4,'TileSpacing','compact','Padding','compact');
bins = 0:5:100;

for f = 1:4
   
    nexttile
    pcts = map_data{f};
    unres_mask = pcts == 0;
    pcts(unres_mask) = -10; %mark out unresolvable vals with -10
    pcolor(pcts); 
    shading flat;
    colormap(grey_map)  
    clim([0 100]);
    xticks([])
    yticks([])
    title(string(hist_titles(f)))
    axis equal tight
    
    if f == 4
        cb = colorbar;
        cb.Label.String = '% of basalts';
        cb.Label.FontSize = 10;
        cb.Label.Rotation = 270;

    end
   
    nexttile(t, f + 4) 
    hist_vals = cell2mat(hist_data(f));
    histogram(hist_vals, bins, 'Normalization', 'percentage')
    set(gca,'FontSize',10)
    xlabel('% of basalts')
    ylim([0 50])
    xlim([0 100])
    
    if f == 1
        ylabel('Land area (%)')
    end
end


%% Plotting phi against basalt percentile as gradient

[nx, ny, nf] = size(phi_rank_geo); 
basalt_prctiles = ((1:nf) - 1)/(nf - 1) * 100; 
basalt_prctile_cube = repmat(reshape(basalt_prctiles, 1, 1, nf), nx, ny, 1);

phi_flat = phi_rank_geo(:);
camg_flat = ca_rank_geo(:);
basalt_prctile_flat = basalt_prctile_cube(:);

nanmask = ~isnan(phi_flat);
phi_flat = phi_flat(nanmask);
camg_flat = camg_flat(nanmask);
basalt_prctile_flat = basalt_prctile_flat(nanmask);

median_phi = NaN(1, nf);
std_phi    = NaN(1, nf);
uq         = NaN(1, nf);
lq         = NaN(1, nf);

for k = 1:nf
    mask_k = (basalt_prctile_flat == basalt_prctiles(k));
    pcts = phi_flat(mask_k);
    median_phi(k) = median(pcts);
    std_phi(k)    = std(pcts);
    uq(k) = quantile(pcts, 0.75);
    lq(k) = quantile(pcts, 0.25);
end

upper_sd = median_phi + std_phi;
lower_sd = median_phi - std_phi;

figure
subplot(1,2,1)
scatter(basalt_prctile_flat, phi_flat, 1, 'filled', 'MarkerFaceAlpha', 0.05)
xlim([0 100])
ylim([0 8])
grid on
xlabel('Basalt percentile')
ylabel('\phi','FontSize',12,'Rotation',0);

subplot(1,2,2)
hold on

% SD
fill([basalt_prctiles fliplr(basalt_prctiles)], ...
     [upper_sd fliplr(lower_sd)], ...
     [0.8 0.8 0.8], 'EdgeColor', 'none', 'FaceAlpha', 0.4)

% Quartiles
fill([basalt_prctiles fliplr(basalt_prctiles)], ...
     [uq fliplr(lq)], ...
     [0.6 0.8 1.0], 'EdgeColor', 'none', 'FaceAlpha', 0.4)

% Median line
plot(basalt_prctiles, median_phi, 'r', 'LineWidth', 1,'Marker','.')
xlabel('Basalt percentile')
ylabel('\phi','FontSize',12,'Rotation',0);
grid on
xlim([0 100])
ylim([0 8])
legend('±1 SD','IQR','Median','Location','NorthWest')
hold off


%% Average proportions of Ca, Mg and Na in feedstock

ca_molmass = 40.08;
mg_molmass = 24.305;
na_molmass = 22.99;

%mol per kg
ca_mol = basalt_geo.CA_PPM./(1000*ca_molmass);
mg_mol = basalt_geo.MG_PPM./(1000*mg_molmass);
na_mol = basalt_geo.NA_PPM./(1000*na_molmass);

CAT_mol = [ca_mol,mg_mol,na_mol];
CAT_mol_sum = sum(CAT_mol,2);

ca_mol_prc = (ca_mol./CAT_mol_sum)*100;
mg_mol_prc = (mg_mol./CAT_mol_sum)*100;
na_mol_prc = (na_mol./CAT_mol_sum)*100;

mean_ca_prc = mean(ca_mol_prc);
mean_mg_prc = mean(mg_mol_prc);
mean_na_prc = mean(na_mol_prc);

na_cdr_pct = (mean_na_prc/((mean_ca_prc*2)+(mean_mg_prc*2)+mean_na_prc))*100;

%% Map topsoil cation concentrations

figure
tiledlayout(1,3,'TileSpacing','tight')
nexttile
pcolor(flipud(soil_struc.Ca))
shading flat
xticks([])
yticks([])
clim([0 10000])
title('(a) [Ca]','FontSize',16)
axis equal tight
set(gca, 'XColor', 'none', 'YColor', 'none');

nexttile
pcolor(flipud(soil_struc.Mg))
shading flat
xticks([])
yticks([])
clim([0 10000])
title('(b) [Mg]','FontSize',16)
axis equal tight
set(gca, 'XColor', 'none', 'YColor', 'none');

nexttile
pcolor(flipud(soil_struc.Na))
shading flat
xticks([])
yticks([])
clim([0 10000])
title('(c) [Na]','FontSize',16)
axis equal tight
set(gca, 'XColor', 'none', 'YColor', 'none');

cb = colorbar;
cb.Layout.Tile = 'east'; 
cb.Limits = [0 10000]; 
cb.FontSize = 10;
cb.Label.String = 'ppm';
cb.Label.FontSize = 16;
cb.Label.Rotation = 270;

clrmp = load("Colormaps\navia.mat"); 
colormap(f,clrmp.navia)

%% Plot Bulk Density Map 

figure
pcolor(bd_grid)
shading flat
xticks([])
yticks([])
c = colorbar;
c.Label.String = 't/m^3';
c.Label.Rotation = 0;
c.Label.FontSize = 20;
c.FontSize = 20;
colormap(jet)
axis equal tight
set(gca, 'XColor', 'none', 'YColor', 'none');
