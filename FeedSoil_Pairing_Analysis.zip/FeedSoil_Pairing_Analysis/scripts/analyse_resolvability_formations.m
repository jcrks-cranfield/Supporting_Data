% Script for plotting phi resolvability and requisite application rate for a range of 
% basalts and tracersacross England and Wales, using a variable bulk density. Basalts 
% here are from igneous formations deemed suitable for ERW in the literature

%---------------------------------------------------------------------

% !NOTE! requires LandIS bulk density data which are not publicly available as
% of Jan 2026. Code from line 59 onwards will not run without this data.

%---------------------------------------------------------------------

% Clear workspace
clc
clear
close all


%% Import UK Soil Element Data

BGS_elems = {'Ag','Al','As','Ba','Bi','Br','Ca','Cd','Ce','Cl','Co','Cr','Cs','Cu','Fe',...
             'Ga','Ge','Hf','I','In','K','La','Mg','Mn','Mo','Na','Nb','Nd','Ni','P',...
             'Pb','Pd','Rb','S','Sb','Sc','Se','Si','Sm','Sn','Sr','Ta','Th','Ti','Tl',...
             'U','V','W','Y','Yb','Zn','Zr'};

% elements with units wt% within BGS data (all else ppm)
wtPerc_elems = {'Al','Ca','Fe','K','Mg','Mn','Na','P','Si','Ti'}; 

%NaN rows to be removed from data grid
n_extra_rows = 6;   
%conversion from wt% to ppm
perc_2_ppm = 10000;  
%marker for non-values
no_val = -1;           
%preacllocate structure to host element grids
soil_struc = struct(); 

%loop through folder to place element grids in structure
for f = 1:numel(BGS_elems)

        BGS_filename = [BGS_elems{f}, '_grid.txt'];
        BGS_soil_raw = readmatrix(fullfile('..', 'data','BGS_topsoil_elements_1km_raw/',BGS_filename)...
            ,'Delimiter',' ', 'NumHeaderLines', n_extra_rows);
        BGS_soil_raw(BGS_soil_raw == no_val) = NaN;
        BGS_soil_clean = BGS_soil_raw;

        % convert wt% elements to ppm

    if ismember(BGS_elems{f}, wtPerc_elems) 
        BGS_soil_clean = BGS_soil_clean * perc_2_ppm;
    end 
    soil_struc.(BGS_elems{f}) = BGS_soil_clean;     
end

%% Import formation basalt data and soil density

form_rawdata = readtable(fullfile('..','data/','igneous_formations/igneous_forms_ppm.csv'));
form_basalt = form_rawdata;

bd_grid = readmatrix(fullfile('..','data/','processing_bulk_density/LandIS_bd_grid.csv'));
grid_NaNmask = isnan(soil_struc.Ag);
bd_grid(flipud(grid_NaNmask)) = NaN;


%% Set inputs for 'base case'

app_rate = 50;      %feedstock application rate in t/ha
plow_depth = 0.1;   %depth of mixing
e_is = 0.1;         %assumed uncertainty on soil tracer concentration
e_js = 0.1;         %assumed uncertainty on soil cation concentration
e_jf = 0.05;        %assumed uncertainty on feedstock cation concentration
e_if = 0.05;        %assumed uncertainty on feedstock tracer concentration
diss = 0.3;         %assumed fraction of rock dissolution
basalt_dens = 2.9;  %basalt  (t/m^3)

%% 6. Create a UK grid of mass fraction, based on inputs^

%preallocate grids for mass fraction and soil volume
mf_grid = NaN(size(bd_grid));     
vsoil_grid = NaN(size(bd_grid)); 

addpath('..\functions\')

%loop over England and Wales grid to calculate mass fraction
for f = 1:size(bd_grid,1)
    for i = 1:size(bd_grid,2)

        bd_val = bd_grid(f,i);

        if isnan(bd_val)
            continue
        end

        [a_mf, vSoil] = app2massfract(app_rate, bd_val, plow_depth);
        mf_grid(f,i)     = a_mf;
        vsoil_grid(f,i) = vSoil;

    end
end


%% 6. Calculate Phi for all GEOROC basalts at every grid cell, with dynamic tracer selection 
i_list = {'Cr','Ni','Ti'};

num_i = numel(i_list);                              %number of immobile elements
num_f = height(form_basalt);                        %number of feedstocks
[cube_ny, cube_nx] = size(mf_grid);                 %rows and columns for cube creation
soil_cube = NaN(cube_ny, cube_nx, num_i);           %preallocate cube of i elements across UK grid
ratio_cube = NaN(cube_ny, cube_nx, num_i);          %preallocate cube of soil-feedstock ratios in [i] 
tracer_counts = NaN(num_f,num_i);                   
best_i_cube = NaN(cube_ny, cube_nx, num_f);         %preallocate cube of best tracer indices
phi_out = NaN(cube_ny,cube_nx,num_f);              
unres_mask = flipud(isnan(soil_struc.Ag));

for f = 1:num_f
    for i = 1:num_i

        %build cube where each 2D layer is a UK map of tracer i
        soil_cube(:,:,i) = flipud(soil_struc.(i_list{i})); 

        %find value of same tracer within given basalt
        i_f = form_basalt.([(upper(i_list{i})) '_PPM'])(f); 

        %calculate i_f/i_s ratios
        ratio_cube(:,:, i) = i_f./soil_cube(:,:,i);
        nan_mask = any(isnan(ratio_cube), 3);

        %identify optimal tracers by max ratio along the tracer dimension
        [~, best_i] = max(ratio_cube, [], 3);
        best_i(nan_mask) = NaN;
        best_i_cube(:,:,f) = best_i;
       
        for k = 1:num_i 
           tracer_counts(f,k) = sum(best_i(:) == k); 
        end

        dynamic_i_s = NaN(size(best_i)); 
        dynamic_i_f = NaN(size(best_i)); 
        
        %for the best tracer, extract the [i] concentrations in soil and feedstock

        for k = 1:num_i 
            i_mask = (best_i == k); 
            i_layer = soil_cube(:,:,k);
            dynamic_i_s(i_mask) = i_layer(i_mask);
            dynamic_i_f(i_mask) = form_basalt.([(upper(i_list{k})) '_PPM'])(f);  
        end

    end

%calculate phi
phi_out(:,:,f) = phiresolvability(mf_grid,dynamic_i_s,dynamic_i_f,e_is,e_if);

end

mode_tracer_map = mode(best_i_cube, 3);
mode_tracer_counts = mode_tracer_map(:);
mode_tracer_counts = mode_tracer_counts(~isnan(mode_tracer_counts));
count_per_tracer = arrayfun(@(k) sum(mode_tracer_counts == k), 1:num_i);

%% Calculate required application rates for every cation and feedstock

%create 2D grids for cations
ca_grid = flipud(soil_struc.Ca);      
mg_grid = flipud(soil_struc.Mg);
na_grid = flipud(soil_struc.Na);

%get columns of feedstock cation concentration
ca_col = form_basalt.CA_PPM;   
mg_col = form_basalt.MG_PPM;
na_col = form_basalt.NA_PPM;

%create cubes of soil cation grid x number of feedstocks
ca_s_3D = repmat(ca_grid, 1, 1, num_f);    
mg_s_3D = repmat(mg_grid, 1, 1, num_f);
na_s_3D = repmat(na_grid, 1, 1, num_f);

%create cubes of feedstock cation concentrations x number of feedstocks
ca_f_3D = reshape(ca_col, 1, 1, num_f);  
mg_f_3D = reshape(mg_col, 1, 1, num_f);  
na_f_3D = reshape(na_col, 1, 1, num_f);  

%create cubes for mass fraction, soil volume and density
mf_3D = repmat(mf_grid,1,1,num_f);
vsoil_3D = repmat(vsoil_grid,1,1,num_f);
bd_3D = repmat(bd_grid,1,1,num_f);

%required a for ca, mg, and na, for every feedstock
[ca_rate, ~ , ~] = appdissreq(mf_3D, ca_s_3D, ca_f_3D, e_js, e_jf, diss, bd_3D, basalt_dens, vsoil_3D);
[mg_rate, ~ , ~] = appdissreq(mf_3D, mg_s_3D, mg_f_3D, e_js, e_jf, diss, bd_3D, basalt_dens, vsoil_3D);
[na_rate, ~ , ~] = appdissreq(mf_3D, na_s_3D, na_f_3D, e_js, e_jf, diss, bd_3D, basalt_dens, vsoil_3D);

%filter variables
ca_rate_map = ca_rate; %create unfiltered variables for mapping. Preserves negative and high values
mg_rate_map = mg_rate;
na_rate_map = na_rate;

ca_rate(ca_rate < 0 | ca_rate > 5000)= NaN; %filter out negative values in histograms
mg_rate(mg_rate < 0 | mg_rate > 5000) = NaN;
na_rate(na_rate < 0 | na_rate > 5000) = NaN;

%% Calculate resolvable land percentages

%plot land area resolvable
%where resolvable = phi>1 and required application <50
phi_res_frac = NaN(num_f,1);
ca_res_frac = NaN(num_f,1);
na_res_frac = NaN(num_f,1);
mg_res_frac = NaN(num_f,1);
camg_res_frac = NaN(num_f,1);
camg_phi_res_frac = NaN(num_f,1);
CAT_res_frac = NaN(num_f,1);
CAT_phi_res_frac = NaN(num_f,1);

for f = 1:num_f

    % total number of land cells
    land_sum = sum(~isnan(phi_out(:,:,f)), 'all');
    
    phi_res_mask = phi_out(:,:,f) > 1;
    ca_res_mask  = ca_rate(:,:,f) < app_rate;
    na_res_mask  = na_rate(:,:,f) < app_rate;
    mg_res_mask  = mg_rate(:,:,f) < app_rate;

    % counts
    phi_res = sum(phi_res_mask, 'all');
    ca_res  = sum(ca_res_mask,  'all');
    na_res  = sum(na_res_mask,  'all');
    mg_res  = sum(mg_res_mask,  'all');

    % joint resolvability: 
    camg_res = sum(ca_res_mask & mg_res_mask, 'all');
    CAT_res = sum(ca_res_mask & mg_res_mask & na_res_mask, 'all');
    camg_phi_res = sum(ca_res_mask & mg_res_mask & phi_res_mask, 'all');
    CAT_phi_res = sum(ca_res_mask & mg_res_mask & na_res_mask & phi_res_mask, 'all');


    % fractions
    phi_res_frac(f) = (phi_res / land_sum) * 100;
    ca_res_frac(f)  = (ca_res  / land_sum) * 100;
    na_res_frac(f)  = (na_res  / land_sum) * 100;
    mg_res_frac(f)  = (mg_res  / land_sum) * 100;
    camg_res_frac(f) = (camg_res / land_sum) * 100;
    camg_phi_res_frac(f) = (camg_phi_res / land_sum) * 100;
    CAT_res_frac(f) = (CAT_res / land_sum) * 100;
    CAT_phi_res_frac(f) = (CAT_phi_res / land_sum) * 100;

end

%%
% Build raw matrix
res_raw = [ca_res_frac(:), mg_res_frac(:), na_res_frac(:), camg_phi_res_frac(:)];
[res_sorted, sort_idx] = sort(res_raw, 2, 'descend');

f_labels = {"Borrowdale", "Clyde Plateau","Ayrshire","Mull Group",...
    "Ballantrae","Llanelwedd","Lower Antrim","Upper Antrim"};

var_names = {'[Ca] loss','[Mg] loss','[Na] loss','Feed. input & [Ca & Mg] loss'};

colors = [
    0.2 0.4 0.8;   % Ca
    0.9 0.2 0.1;   % Mg
    0.8 0.9 0.2;   % Na
    0.1 0.7 0.3];  % Ca+Mg+phi

figure;
h = bar(res_sorted, 'grouped');   % h is an array of bar objects
for k = 1:numel(h)
    h(k).FaceColor = colors(k,:);
end
set(gca, 'XTick', 1:8, 'XTickLabel', f_labels)
ylabel('Land area resolved (%)');
xlabel('Feedstock');
grid on
legend(var_names,'Location','northoutside','Orientation','horizontal')

%%

figure

for f = 1:8

phi_res_mask = phi_out(:,:,f) > 1;
ca_res_mask  = ca_rate(:,:,f) < app_rate;
na_res_mask  = na_rate(:,:,f) < app_rate;
mg_res_mask  = mg_rate(:,:,f) < app_rate;
res_combined = double(ca_res_mask & mg_res_mask & phi_res_mask);

land_mask = unres_mask;
res_map = res_combined;
res_map(land_mask) = NaN;

subplot(2,4,f)
pcolor(res_map)
shading flat
axis equal tight
set(gca,'Color','w')
xticks([])
yticks([])
colormap([
 0.6 0.6 0.6
    0 1 0])

hold on
contour(double(land_mask), [0.5 0.5], 'k', 'LineWidth', 0.5)
hold off

hold on
h = patch(NaN, NaN, [0 1 0]);  
hold off

title(f_labels(f))

end

%%


