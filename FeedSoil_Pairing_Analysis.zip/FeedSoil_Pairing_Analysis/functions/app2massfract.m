
function [a_mf, v_soil] = app2massfract(app_rate, dens_soil, plow_depth)

% app2massfrac calculates the mass fraction of feedstock in soil from the
% application rate, density and volume of soil. Written from formulae derived in 
% Suhrhoff et al.(2024).

%---------------------------------------------------------------------

%VARIABLES

% app_rate = feedstock application rate (t/ha)
% dens_soil = bulk density of soil (t/m^3) or (g/cm^3)
% plow_depth = depth to which feedstock is mixed (m)

%area of 1 hectare
ha_m2 = 100*100;  

%volume of soil across 1 hectare
v_soil = ha_m2*plow_depth; 

%calculation
a_mf = app_rate/((dens_soil*v_soil)+app_rate); 

%-----------------------------------------------------------------------

%Reference: 

%Suhrhoff TJ, Reershemius T, Wang J, Jordan JS, Reinhard CT, Planavsky NJ. 
% A tool for assessing the sensitivity of soil-based approaches for quantifying enhanced weathering: 
% a US case study. Frontiers in Climate. 2024 Apr 12;6:1346117. 
% DOI:https://doi.org/10.3389/fclim.2024.1346117