% Script for plotting phi resolvability and requisite application rate for a range of 
% basalts and tracersacross England and Wales, using a variable bulk density. Basalts 
% here are from igneous formations deemed suitable for ERW in the literature

%---------------------------------------------------------------------

% !NOTE! requires LandIS bulk density data which are not publicly available as
% of Jan 2026. Code from line 59 onwards will not run without this data.

%---------------------------------------------------------------------

%clear workspace
clc
clear
close all


%% Import UK Soil Element Data

BGS_elems = {'Ag','Al','As','Ba','Bi','Br','Ca','Cd','Ce','Cl','Co','Cr','Cs','Cu','Fe',...
             'Ga','Ge','Hf','I','In','K','La','Mg','Mn','Mo','Na','Nb','Nd','Ni','P',...
             'Pb','Pd','Rb','S','Sb','Sc','Se','Si','Sm','Sn','Sr','Ta','Th','Ti','Tl',...
             'U','V','W','Y','Yb','Zn','Zr'};

%elements with units wt% within BGS data (all else ppm)
wtPerc_elems = {'Al','Ca','Fe','K','Mg','Mn','Na','P','Si','Ti'}; 

%NaN rows to be removed from data grid
n_extra_rows = 6;   
%conversion from wt% to ppm
perc_2_ppm = 10000;  
%marker for non-values
no_val = -1;           
%preacllocate structure to host element grids
soil_struc = struct(); 

%loop through folder to place element grids in structure
for f = 1:numel(BGS_elems)

        BGS_filename = [BGS_elems{f}, '_grid.txt'];
        BGS_soil_raw = readmatrix(fullfile('..', 'data','BGS_topsoil_elem_1km/',BGS_filename)...
            ,'Delimiter',' ', 'NumHeaderLines', n_extra_rows);
        BGS_soil_raw(BGS_soil_raw == no_val) = NaN;
        BGS_soil_clean = BGS_soil_raw;

        % convert wt% elements to ppm

    if ismember(BGS_elems{f}, wtPerc_elems) 
        BGS_soil_clean = BGS_soil_clean * perc_2_ppm;
    end 
    soil_struc.(BGS_elems{f}) = BGS_soil_clean;     
end

%% Import formation basalt data and soil density

rawdata_form = readtable(fullfile('..','data/','igneous_form_data/igneous_forms_v2.csv'));
basalt_form = rawdata_form;

bd_grid = readmatrix(fullfile('..','data/','processing_bulk_density/LandIS_bd_grid.csv'));
grid_NaNmask = isnan(soil_struc.Ag);
bd_grid(flipud(grid_NaNmask)) = NaN;


%% Set inputs for 'base case'

app_rate = 50;      %feedstock application rate in t/ha
plow_depth = 0.1;   %depth of mixing
e_is = 0.1;         %assumed uncertainty on soil tracer concentration
e_js = 0.1;         %assumed uncertainty on soil cation concentration
e_jf = 0.05;        %assumed uncertainty on feedstock cation concentration
e_if = 0.05;        %assumed uncertainty on feedstock tracer concentration
diss = 0.3;         %assumed fraction of rock dissolution
basalt_dens = 2.9;  %basalt  (t/m^3)

%% Create a UK grid of mass fraction, based on inputs^

%preallocate grids for mass fraction and soil volume
mf_grid = NaN(size(bd_grid));     
vsoil_grid = NaN(size(bd_grid)); 

addpath('..\functions\')

%loop over UK grid 
for f = 1:size(bd_grid,1)
    for i = 1:size(bd_grid,2)

        bd_val = bd_grid(f,i);

        if isnan(bd_val)
            continue
        end

        [a_mf, vSoil] = app2massfract(app_rate, bd_val, plow_depth);
        mf_grid(f,i)     = a_mf;
        vsoil_grid(f,i) = vSoil;

    end
end


%% Calculate Phi for all formation basalts at every grid cell, with dynamic tracer selection 

%PREALLOCATE VARIABLES
i_list = {'Cr','Ni','Ti'};
num_i = numel(i_list);                           %number of tracers
num_f_form = height(basalt_form);                %number of igneous formation feedstocks
[cube_ny, cube_nx] = size(mf_grid);              %cube size   
soil_cube = NaN(cube_ny, cube_nx, num_i);        %preallocate cube of xy spatial grid vs z tracers
ratio_cube = NaN(cube_ny, cube_nx, num_i);       %preallocate cube to store [i]f/[i]s ratios
best_i_cube = NaN(cube_ny, cube_nx, num_f_form); %preallocate cube to store optimal tracer indices

phi_form  = NaN(cube_ny, cube_nx, num_f_form);   %phi using optimal tracer
unres_mask = flipud(isnan(soil_struc.Ag));       %Mask for non values (sea)
basalt_mat = NaN(num_f_form, num_i);             %feedstocks x tracers matrix
dynamic_i_s  = NaN(cube_ny, cube_nx);            %best tracer, soil conc
dynamic_i_f  = NaN(cube_ny, cube_nx);            %best tracer, feed conc

%----------------------------------------------------------------------------------

%extract grid of concentration vals for every tracer
for i = 1:num_i
    soil_cube(:,:,i) = flipud(soil_struc.(i_list{i}));
end

%extract concentration vals for every tracer in every basalt
for i = 1:num_i
    basalt_mat(:,i) = basalt_form.([(upper(i_list{i})) '_PPM']);
end

for f = 1:num_f_form
   
       %calculate [i] ratios for this basalt and tracer
       ratio_cube = reshape(basalt_mat(f,:), 1, 1, num_i) ./ soil_cube;
       nan_mask = any(isnan(ratio_cube), 3);

        %identify optimal tracers by max ratio along the tracer dimension
        [~, best_i] = max(ratio_cube, [], 3);
        best_i(nan_mask) = NaN;
        best_i_cube(:,:,f) = best_i;

        dynamic_i_s = NaN(size(best_i)); 
        dynamic_i_f = NaN(size(best_i)); 
        
        for k = 1:num_i 

            klayer = soil_cube(:,:,k);      
            mask = best_i == k;
            dynamic_i_s(mask) = klayer(mask);
            dynamic_i_f(mask) = basalt_mat(f,k);

        end
phi_form(:,:,f) = phiresolvability(mf_grid,dynamic_i_s,dynamic_i_f,e_is,e_if);

end


mode_tracer_map = mode(best_i_cube, 3);
mode_tracer_counts = mode_tracer_map(:);
mode_tracer_counts = mode_tracer_counts(~isnan(mode_tracer_counts));
count_per_tracer = arrayfun(@(k) sum(mode_tracer_counts == k), 1:num_i);

%% Calculate required application rates for every cation and feedstock

%create 2D grids for cations
ca_grid = flipud(soil_struc.Ca);      
mg_grid = flipud(soil_struc.Mg);
na_grid = flipud(soil_struc.Na);

%get columns of feedstock cation concentration
ca_col = basalt_form.CA_PPM;   
mg_col = basalt_form.MG_PPM;
na_col = basalt_form.NA_PPM;

%create cubes of soil cation grid x number of feedstocks
ca_s_3D = repmat(ca_grid, 1, 1, num_f_form);    
mg_s_3D = repmat(mg_grid, 1, 1, num_f_form);
na_s_3D = repmat(na_grid, 1, 1, num_f_form);

%create cubes of feedstock cation concentrations x number of feedstocks
ca_f_3D = reshape(ca_col, 1, 1, num_f_form);  
mg_f_3D = reshape(mg_col, 1, 1, num_f_form);  
na_f_3D = reshape(na_col, 1, 1, num_f_form);  

%create cubes for mass fraction, soil volume and density
mf_3D = repmat(mf_grid,1,1,num_f_form);
vsoil_3D = repmat(vsoil_grid,1,1,num_f_form);
bd_3D = repmat(bd_grid,1,1,num_f_form);

%required a for ca, mg, and na, for every feedstock
[ca_rate, ~ , ~] = appdissreq(mf_3D, ca_s_3D, ca_f_3D, e_js, e_jf, diss, bd_3D, basalt_dens, vsoil_3D);
[mg_rate, ~ , ~] = appdissreq(mf_3D, mg_s_3D, mg_f_3D, e_js, e_jf, diss, bd_3D, basalt_dens, vsoil_3D);
[na_rate, ~ , ~] = appdissreq(mf_3D, na_s_3D, na_f_3D, e_js, e_jf, diss, bd_3D, basalt_dens, vsoil_3D);

%filter variables
ca_rate_map = ca_rate; %create unfiltered variables for mapping. Preserves negative and high values
mg_rate_map = mg_rate;
na_rate_map = na_rate;

ca_rate(ca_rate < 0 | ca_rate > 5000)= NaN; %filter out negative values in histograms
mg_rate(mg_rate < 0 | mg_rate > 5000) = NaN;
na_rate(na_rate < 0 | na_rate > 5000) = NaN;

%% Calculate resolvable land percentages

%plot land area resolvable
%where resolvable = phi>1 and required application <50
phi_res_frac = NaN(num_f_form,1);
ca_res_frac = NaN(num_f_form,1);
na_res_frac = NaN(num_f_form,1);
mg_res_frac = NaN(num_f_form,1);
camg_res_frac = NaN(num_f_form,1);
camg_phi_res_frac = NaN(num_f_form,1);
CAT_res_frac = NaN(num_f_form,1);
CAT_phi_res_frac = NaN(num_f_form,1);

for f = 1:num_f_form

    %total number of land cells
    land_sum = sum(~isnan(phi_form(:,:,f)), 'all');
    
    %indices for resolvable signals
    phi_res_mask = phi_form(:,:,f) > 1;
    ca_res_mask  = ca_rate(:,:,f) < app_rate;
    na_res_mask  = na_rate(:,:,f) < app_rate;
    mg_res_mask  = mg_rate(:,:,f) < app_rate;

    %counts of the above
    phi_res = sum(phi_res_mask, 'all');
    ca_res  = sum(ca_res_mask,  'all');
    na_res  = sum(na_res_mask,  'all');
    mg_res  = sum(mg_res_mask,  'all');

    %counts for joint resolvability
    camg_res = sum(ca_res_mask & mg_res_mask, 'all');
    CAT_res = sum(ca_res_mask & mg_res_mask & na_res_mask, 'all');
    camg_phi_res = sum(ca_res_mask & mg_res_mask & phi_res_mask, 'all');
    CAT_phi_res = sum(ca_res_mask & mg_res_mask & na_res_mask & phi_res_mask, 'all');

    %fractions of resolvable land area
    phi_res_frac(f) = (phi_res / land_sum) * 100;
    ca_res_frac(f)  = (ca_res  / land_sum) * 100;
    na_res_frac(f)  = (na_res  / land_sum) * 100;
    mg_res_frac(f)  = (mg_res  / land_sum) * 100;
    camg_res_frac(f) = (camg_res / land_sum) * 100;
    camg_phi_res_frac(f) = (camg_phi_res / land_sum) * 100;
    CAT_res_frac(f) = (CAT_res / land_sum) * 100;
    CAT_phi_res_frac(f) = (CAT_phi_res / land_sum) * 100;

end

%% Plot bars of resolvability for different cation losses across the igneous formation samples

res_raw = [ca_res_frac(:), mg_res_frac(:), na_res_frac(:), camg_phi_res_frac(:)];
[res_sorted, sort_idx] = sort(res_raw, 2, 'descend');

f_labels = {"Borrowdale", "Clyde Plateau","Ayrshire","Mull Group",...
    "Ballantrae","Llanelwedd","Lower Antrim","Upper Antrim"};

var_names = {'[Ca] loss','[Mg] loss','[Na] loss','Feed. input & [Ca & Mg] loss'};

colors = [
    0.2 0.4 0.8;   % Ca
    0.9 0.2 0.1;   % Mg
    0.8 0.9 0.2;   % Na
    0.1 0.7 0.3];  % Ca+Mg+phi

figure('Position',[100 100 900 400])
h = bar(res_sorted, 'grouped');   % h is an array of bar objects

for k = 1:numel(h)
    h(k).FaceColor = colors(k,:);
end

set(gca, 'XTick', 1:8, 'XTickLabel', f_labels)
set(gca,'FontName','Times New Roman')
set(gca,'FontSize',10)
ylabel('Land area resolved (%)');
grid on
legend(var_names,'Location','northoutside','Orientation','horizontal')

%% Plot areas where Phi, Ca, and Mg are all resolvable (at <50t/ha) for each formation sample

figure
for f = 1:8

phi_res_mask = phi_form(:,:,f) > 1;
ca_res_mask  = ca_rate(:,:,f) < app_rate;
na_res_mask  = na_rate(:,:,f) < app_rate;
mg_res_mask  = mg_rate(:,:,f) < app_rate;
res_combined = double(ca_res_mask & mg_res_mask & phi_res_mask);

land_mask = unres_mask;
res_map = res_combined;
res_map(land_mask) = NaN;

subplot(2,4,f)
pcolor(res_map)
shading flat
axis equal tight
set(gca,'Color','w')
xticks([])
yticks([])
colormap([
 0.6 0.6 0.6
    0 1 0])

hold on
contour(double(land_mask), [0.5 0.5], 'k', 'LineWidth', 0.5)
hold off

hold on
h = patch(NaN, NaN, [0 1 0]);  
hold off

title(f_labels(f))

end




