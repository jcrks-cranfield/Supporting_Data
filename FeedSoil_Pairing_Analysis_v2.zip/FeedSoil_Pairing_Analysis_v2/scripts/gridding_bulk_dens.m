% Script for pairing LandIS HORIZON samples' bulk density values in the 
% to NSI samples, using soil series, soil horizon, and land use designation
% within the LandIS NSI Site dataset

% !NOTE! requires LandIS bulk density data which are not publicly available as
% of Jan 2026. This script will not run without the relevant datasets, so
% is provided primarily as a methodological reference.

%% Clear workspace
clc
clear
close all

%% Import LandIS Datasets

hyd_file = fullfile('..', 'data', 'processing_bulk_density', 'HORIZONhydraulics_V2_1.csv');
hyd_data = readtable(hyd_file);
site_file = fullfile('..', 'data', 'processing_bulk_density', 'NSI_SITE.csv');
site_data = readtable(site_file);

%give landuse consistent notation between datasets
lu = string(site_data.LANDUSE);
lu = replace(lu, "permanent grassland", "PG");  
lu = replace(lu, "arable", "A"); 
lu = replace(lu, "ley grassland", "LE");

%anything not permanent grassland, arable, or ley grassland gets other (OT)
l_u_valid = ["PG","AR","LE"]; 
lu(~ismember(lu, l_u_valid)) = "OT"; 
site_data.LANDUSE = lu;             

hyd_data.SERIES_NAME = string(hyd_data.SERIES_NAME);
hyd_data.DESIGNATION = string(hyd_data.DESIGNATION);
hyd_data.LU_GROUP    = string(hyd_data.LU_GROUP);

%% Loop to match values

%preallocate bulk density and lower depth of A horizon columns
site_data.BD = nan(height(site_data),1); 
site_data.LOWER_DEPTH = nan(height(site_data),1);

for i = 1:height(site_data)

   single_ser = string(site_data.SERIES_NAME(i));
   single_lu = string(site_data.LANDUSE(i));

   %get indices of series, A horizon, and landuse
   ser_idx = hyd_data.SERIES_NAME == single_ser;
   topsl_idx = hyd_data.DESIGNATION == 'A'; %A topsoil layer
   lu_idx = hyd_data.LU_GROUP == single_lu;
   all_idx = ser_idx & topsl_idx & lu_idx;

   %match bulk density at the above indices
   if any(all_idx)
       site_data.BD(i) = hyd_data.BULK_DENSITY(all_idx);       
       site_data.LOWER_DEPTH(i) = hyd_data.LOWER_DEPTH(all_idx);
   else
       site_data.BD(i) = NaN; 
       site_data.LOWER_DEPTH(i) = NaN;  

   end
end

% export matched bulk density with north and east coords
bd_export = table( ...
    site_data.EAST_NSI, ...
    site_data.NORTH_NSI, ...
    site_data.BD, ...
    'VariableNames', {'EAST_NSI','NORTH_NSI','BD'} );

writetable(bd_export, 'LandIS_matched_bd.csv');

% The above bulk density table is exported into ArcGIS for IDW interpolation 
% onto the British National Grid (1x1km). Values are taken at the lower left 
% corners of grid cells as the reference system begins at (0N,0E).

%% Map bulk density

figure;
scatter(site_data.EAST_NSI, site_data.NORTH_NSI, 60, site_data.BD, 'filled');
xlabel('Easting (m)');
ylabel('Northing (m)');
title('Bulk Density Distribution (NSI Samples)');
colormap(parula);    
colorbar;
c = colorbar;
c.Label.String = 'Bulk Density (g/cm^3)';


%% Re-import ArcGIS-inteprolated bulk densities, create grid for incorporation into phi/a/b calculations

Arc_bd_XY_file = fullfile('..', 'data', 'processing_bulk_density','LandIS_bd_IDW_pointXY.csv');
Arc_bd_XY = readtable(Arc_bd_XY_file);

% Round coordinates to nearest 1 km
x_m = round(Arc_bd_XY.X / 1000) * 1000;   % Easting
y_m = round(Arc_bd_XY.Y / 1000) * 1000;   % Northing
x_km = x_m / 1000;   
y_km = y_m / 1000;  

%extract bulk density values from interpolated data (column)
bd_val = Arc_bd_XY.RASTERVALU;   

%preallocate grid, same size as element data (640km x 515km)
grid = NaN(640,515);   
 
%place interpolated values on grid
for i = 1:height(bd_val)

    row = x_km(i) - min(x_km)+1;
    col = y_km(i) - min(y_km)+1;
    grid(col,row) = bd_val(i);

end

% export grid to 'data' -> 'processing_bulk_density' for use in further calculations
base = fileparts(pwd);
dataDir = fullfile(base,'data','processing_bulk_density');
writematrix(grid, fullfile(dataDir,'LandIS_bd_grid.csv'));




