function phi = phiresolvability(a_mf, i_s, i_f, e_s_assumed, e_f_assumed)

% phiresolvability calculates the dimensionless phi resolvability parameter
% from Suhrhoff et al (2024) for a single immobile element (i)

%VARIABLES

% a_mf = mass fraction of feedstock applied to soil
% i_s = concentration of i in soil (ppm)
% i_f = concentration of i in feedstock (ppm)
% e_s_assumed =  assumed uncertainty on i_s measurement (decimal)
% e_f_assumed = assumed uncertainty on the i_f measurement (decimal)


% If ANY input parameter is NaN, the output phi is also NaN.
nan_mask = isnan(a_mf) | isnan(i_s) | isnan(i_f) | ...
           isnan(e_s_assumed) | isnan(e_f_assumed);

e_is = i_s .* e_s_assumed; 
e_if = i_f .* e_f_assumed;

num = abs((a_mf.*i_f)+((1-a_mf).*i_s)-i_s);
den = (2.*e_is) + ((e_if-e_is).*a_mf);
phi = num./den;

% Apply NaN mask to output
phi(nan_mask) = NaN;

end


%-----------------------------------------------------------------------

%Reference: 

%Suhrhoff TJ, Reershemius T, Wang J, Jordan JS, Reinhard CT, Planavsky NJ. 
% A tool for assessing the sensitivity of soil-based approaches for quantifying enhanced weathering: 
% a US case study. Frontiers in Climate. 2024 Apr 12;6:1346117. 
% DOI:https://doi.org/10.3389/fclim.2024.1346117