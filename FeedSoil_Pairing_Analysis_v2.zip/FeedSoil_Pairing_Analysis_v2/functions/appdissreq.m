
function [a_rate, a_frac,b_perc] = appdissreq(a_mf, j_s, j_f, assumed_e_js, assumed_e_jf, assumed_diss, dens_soil, dens_feed, vol_soil)

% appdissreq calculates the application rate and dissolution fraction of
% feedstock required to generate a resolvable weathering signal, as in
% Suhrhoff et al. (2024).
% 
% a_rate is the required application rate in t/ha, a_frac is the required application 
% rate represented as a mass fraction, b_perc is the required dissolution fraction in 
% decimals

%------------------------------------------------------------------------

%VARIABLES

% a_mf = feedstock application rate, as a mass fraction of feedstock in soil
% j_s = concentration of whole base cation in soil (ppm)
% j_f = concentration of whole base cation in feedstock (ppm)
% assumed_e_js = assumed uncertainty on soil cation concentration (decimal)
% assumed_e_jf = assumed uncertainty on feedstock cation concentration (decimal)
% assumed_diss = assumed dissolution (decimal fraction)

%multiply cation concentrations by assumed uncertainties
e_js = assumed_e_js.* j_s;
e_jf = assumed_e_jf.* j_f;

%calculate  required dissolution
b_num = 2.*((1-a_mf)./a_mf).*(e_js .* j_s)+(e_js .* j_f)+(e_jf .* j_s);
b_den = (j_s .* j_f) + (e_js .* j_f);
b = b_num./b_den;
b_perc = b.*100;

%calculate  required application
a_num = 2.*e_js.*j_s;
a_den = (((j_s.*j_f)+(e_js.*j_f)).*assumed_diss) - ((e_js.*j_f)+(e_jf.*j_s)+(2.*e_js.*j_s));
a_frac = a_num./a_den;
a_rate = a_frac./dens_feed./((1-a_frac)./dens_soil).*(vol_soil.*dens_feed);


%-----------------------------------------------------------------------

% Reference: 

% Suhrhoff TJ, Reershemius T, Wang J, Jordan JS, Reinhard CT, Planavsky NJ. 
% A tool for assessing the sensitivity of soil-based approaches for quantifying enhanced weathering: 
% a US case study. Frontiers in Climate. 2024 Apr 12;6:1346117. 
% DOI:https://doi.org/10.3389/fclim.2024.1346117




