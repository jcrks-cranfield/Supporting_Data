
Data history:
1. Original data sourced from georoc.eu online depository, by Lehnert et al. (2000).
2. GEOROC samples first queried by geography, limited to the UK: -8 to 0 E, 50 to 59N (n=12295)
3. Filtered -> Land/Sea(sampling) = 'Subaerial', Rock Type = 'Volcanic Rock'
4. Exported to GEOROC_samples_raw

Reference: Lehnert K, Su Y, Langmuir CH, Sarbas B, Nohl U. A global geochemical database structure for rocks. Geochemistry, Geophysics, Geosystems. 2000 May;1(5).


Processing of GEOROC_samples_raw into GEOROC_samples_processed:
A) Oxides converted to pure elements B) wt% (weight percent) values converted to ppm. Where ppm values already existed for an element, these were used. Where only oxides existed, these were used (excluding alternative values or methods). C) Headers renamed to MATLAB-readable formats D) Element columns  restricted to CA_PPM, MG_PPM NA_PPM K_PPM P_PPM TI_PPM AL_PPM	CR_PPM	NI_PPM	Y_PPM NB_PPM TH_PPM SC_PPM RB_PPM HF_PPM TA_PPM. Other elements were excluded due to their mobility in soils, lack of entries, or relevance to ERW. E) Irrelevant columns removed for ease of use F) MATERIAL column filtered to 'Whole Rock'.

GEOROC_samples_processed headers:

YEAR = Year of sampling
CITATION = Reference for sampling (full references in raw data)
SAMP_NAME = Unique sample name 
ROCK_NAME = Name of rock
MATERIAL = Type of material, e.g. mineral, glass, whole rock
LAT_MIN = Minimum latitude of sample (WGS84 datum)
LONG_MIN = Minimum longitude of sample (WGS84 datum)
LAT_MAX = Maximum latitude of sample (WGS84 datum)
LONG_MAX = Maximum longitude of sample (WGS84 datum)

Columns J-Y are element concentrations, where the first letters are uppercase element symbols.










