BGS_topsoil_elem_1km:

52 .txt grids of element concentrations within 0-15cm topsoil, interpolated by the British Geological Survey (BGS) across England and Wales at 1 x 1km resolution. Values are determined by XRF via the methodology of Rawlins et al. (2012). Values are ppm for minor elements, but wt% (weight percent) for: Aluminium, calcium, Iron, Potassium, Magnesium, Manganese, Sodium, Phosphorus, Silicon, Titanium. These wt% elements are converted to ppm in the supplementary MATLAB code. 

This data is derived from research conducted by BGS and Rothamsted Research, and is based on soil samples collected for the National Soil Inventory (NSI) by the Soil Survey of England and Wales (now the National Soil Resources Institute, Cranfield University). These NSI samples were collected at 5km gridpoints of the British National Grid. Values which do not correspond to measured land are marked as '-1'.

This data is available for download from:https://www.bgs.ac.uk/download/advanced-soil-geochemical-atlas-nsi-grids/

Reference: Rawlins, B G, McGrath, S P, Scheib, A J, Breward, N, Cave, M, Lister, T R, Ingham, M, Gowing, C and Carter, S. 2012. The advanced soil geochemical atlas of England and Wales. British Geological Survey, Keyworth. 
